<?php  
session_start();  
if(isset($_SESSION['SNK_email']) && $_SESSION['SNK_gender']!='Male' )
{  
     $Page_Name = 'Grooms List'; 
  include('header.php');
?>  
  


        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"><?php echo $Page_Name; ?></h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <?php echo $Page_Name; ?>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
							
							
						<thead>
							<tr>
							    <th>Reg.No.</th>
							    
								<th>Reg.Date</th>
								<th>Height</th>
								<th>Date Of Birth</th>
								<th>Education</th>
								<th>Residence</th>
								<th>Occupation</th>
				  
							</tr>
						</thead>
					
						<tfoot>
							<tr>
							    <th>Reg.No.</th>
							   
								<th>Reg.Date</th>
								<th>Height</th>
								<th>Date Of Birth</th>
								<th>Education</th>
								<th>Residence</th>
								<th>Occupation</th>
							</tr>
						</tfoot>
					
						<tbody>
						
						
						<?php
    include 'config.php';
    function convert_to_inches($cm) {
    	$inches = round($cm * 0.393701);
    	$result = [
    		'ft' => intval($inches / 12),
    		'in' => $inches % 12,
    	];
    
    	return $result;
    }
	$query="select * from members where gender='Male'and status='1'";
	$run = mysqli_query($con, $query);
	$count = mysqli_num_rows($run);
	//echo $count;
	if($count>0)
	{
	    $ind = 0;
		while($row=mysqli_fetch_assoc($run))
		{
			if($row['height']!='')
		    {
			$height = convert_to_inches($row['height']);
		    }
		    else
		    {
		        $height = '';
		    }
		 ?>
		 <style>
		
.table_image {
  position: absolute;
  width: 500px;
  left:0px;
  top: 0px;
  text-align: center;
  opacity: 0;
  transition: opacity .35s ease;
}


td.container2 {
    position: relative;
    width: 15%;
}



.container2:hover .table_image {
  opacity: 1;
  display:block;
}
.pagination>li>a:hover { 
    background-color: #4285f4;
 color:#fcfcfc;
}
		</style>
							<tr>
							   
								
								
								<td class="container2" >
								<a class="btn btn-blue" onclick="view(<?php echo $row['id']; ?>)">
											<img src="../img/images/<?php echo $row['file_name']; ?>" class="table_image"  style="border-radius: 5px;width:200px;display:none" >
											<?php echo $row['regid']; ?>
								</a>
								</td>
								<td><?php 
								date_default_timezone_set("Asia/Calcutta");
								echo date('d M Y',strtotime($row['created_at'])); ?></td>
								<td><?php if($height!='') echo $height['ft'].'ft '.$height['in'].'in - '.$row['height'].'cm'; ?></td>
								<td><?php echo $row['dob']; ?></td>
								<td><?php echo $row['education']; ?></td>
								<td><?php echo $row['residence_city']; ?></td>
								<td><?php echo $row['occupation']; ?></td>
							</tr>
							
							
							
							 <?php 
							 $ind++;
		}
	}
		  
	  ?>
							
							
							
						</tbody>
					</table>
                            <!-- /.table-responsive -->
                           
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
 
        </div>
        <!-- /#page-wrapper -->
					
					<script>
					    function showImg(event,id)
					    {
					        document.getElementById("button_"+id).style.visibility="visible";
					    }
					    function hideImg(event,id)
					    {
					        document.getElementById("button_"+id).style.visibility="hidden";
					    }
					    function view(id)
					    {
					        jQuery.post("http://www.sankalpbuddhist.com/viewdata.php?id="+id, function( result ) {
                                         console.log(result);
                        		jQuery("#groomview").html(result);
                        		jQuery("#groomsajax").css("display","none");
                        		jQuery("#groomview").css("display","block");
                        	});
					    }
					    function back()
					    {
					        jQuery("#groomsajax").css("display","block");
                        	jQuery("#groomview").css("display","none");
					    }
					</script>
<?php 
include('footer.php');

}
else if(!$_SESSION['SNK_email'])  
{  
    header("Location: login.php");//redirect to login page to secure the welcome page without login access.  
}  
?>