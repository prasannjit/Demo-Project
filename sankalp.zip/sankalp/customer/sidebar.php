<div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        
                        <li>
                            <a href="home.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
                       
						<li><?php 
						  if($_SESSION['SNK_gender']!='Male')  
						  {
							?><a href="grooms.php"><i class="fa fa-table fa-fw"></i>  grooms </a>  <?php   
						  }
						  
						  if($_SESSION['SNK_gender']=='Male')  
						  {
							?><a href="bride.php"><i class="fa fa-table fa-fw"></i>  bride </a>  <?php   
						  }
						 ?>     
						 </li>
						
                        <li><a href="profile.php"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>