<?php  
session_start();  
if(isset($_SESSION['SNK_email']) )
{   
$Page_Name = 'Home'; 
  include('header.php');
?> 
 
         <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"><?php echo $Page_Name; ?></h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
						<div class="panel-heading">
                            <?php echo $Page_Name; ?>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
					
					
							<h1><i class="fa fa-user fa-fw"></i> Welcome  <?php  echo $_SESSION['SNK_name'];   ?></h1>

 
 
						</div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
 
        </div>
        <!-- /#page-wrapper -->

<?php 
include('footer.php');

}
else if(!$_SESSION['SNK_email'])  
{  
    header("Location: login.php");//redirect to login page to secure the welcome page without login access.  
}  
?>