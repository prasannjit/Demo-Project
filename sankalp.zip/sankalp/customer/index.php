<?php  
session_start();//session starts here  
  
?>  
<html>  
<head lang="en">  
    <meta charset="UTF-8">  
    <link type="text/css" rel="stylesheet" href="bootstrap-3.2.0-dist\css\bootstrap.css">  
    <title>Login</title>  
</head>  
<style>  
    .login-panel {  
        margin-top: 150px;  
	}
</style>  
  
<body>  
  
<?php  
  
include 'config.php';
  //include("customer/Db_conection.php");  
  
if(isset($_POST['login']))  
{  
    $email =$_POST['email'];  
    $password =$_POST['pass'];  
  
    $check_user="select * from members WHERE email='$email' AND password='".md5($password)."'";  
	echo $check_user;
    $run=mysqli_query($con,$check_user);  
  
    if(mysqli_num_rows($run))  
    {  
		echo $check_user;
        while($row = mysqli_fetch_assoc($run))
		{
		$_SESSION['SNK_id'] = $row['id'];
        $_SESSION['SNK_email'] = $row['email']; //here session is used and value of $user_email store in $_SESSION. 
		$_SESSION['SNK_name'] = $row['fname'].' '.$row['lname'];
		$_SESSION['SNK_gender'] = $row['gender'];
		$_SESSION['SNK_dob'] = $row['dob'];
		$_SESSION['SNK_mobile'] = $row['mobile_1'];
		}

		echo "<meta http-equiv='refresh' content='0;url=./home.php'>"; 
		//echo "<script>window.open('welcome.php','_self')</script>";  
  
    }  
    else  
    {  
      echo "<script>alert('Email or password is incorrect!')</script>";  
    }  
}  
?>    
  
<div class="container">  
    <div class="row">  
        <div class="col-md-4 col-md-offset-4">  
            <div class="login-panel panel panel-success">  
                <div class="panel-heading">  
                    <h3 class="panel-title">Sign In</h3>  
                </div>  
                <div class="panel-body">  
                    <form role="form" method="post" >  
                        <fieldset>  
                            <div class="form-group"  >  
                                <input class="form-control" placeholder="E-mail" name="email" type="email" autofocus>  
                            </div>  
                            <div class="form-group">  
                                <input class="form-control" placeholder="Password" name="pass" type="password" value="">  
                            </div>  
                                <input class="btn btn-lg btn-success btn-block" type="submit" value="login" name="login" >  
  
                            <!-- Change this to a button or input when using this as a form -->  
                          <!--  <a href="index.html" class="btn btn-lg btn-success btn-block">Login</a> -->  
                        </fieldset>  
                    </form>  
                </div>  
            </div>  
        </div>  
    </div>  
</div>  
  
  
</body>  
  
</html>  
