<?php  
session_start();  
if(isset($_SESSION['SNK_email']) )
{  

 $Page_Name = 'Profile'; 
   
  include('header.php');
?>  
  
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"><?php echo $Page_Name; ?></h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <?php echo $Page_Name; ?>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
<script src="../script.js"></script>
<?php
$SNK_id  = $_GET['del'];
//session_start();
include 'config.php';
//print_r($con);

//print_r($_POST);
if(isset($_POST['saveregister']))
{
// Personal Details 
//echo 'innnnnnnnnnnnnnnnnnnn';
//print_r($POST);
//exit();

//$id=$_POST["id"];
//$regid=$_POST["regid"];
$fname=$_POST["fname"];
$mname=$_POST["mname"];
$lname=$_POST["lname"];
$dob=$_POST["dob"];
$gender=$_POST["gender"];
$subcast=$_POST["subcast"];
$marital_status=$_POST["marital_status"];
$height=$_POST["height"];
$weight=$_POST["weight"];
$blood_group=$_POST["blood_group"];
$complextion=$_POST["complextion"];
$physical_dis=$_POST["physical_dis"];
$diet=$_POST["diet"];
$specify=$_POST["specify"];
$spectacles=$_POST["spectacles"];
$lens=$_POST["lens"];
$personality=$_POST["personality"];
$age=$_POST["age"];

// Horoscop Details

$rashi=$_POST["rashi"];
$nakshtra=$_POST["nakshtra"];
$charan=$_POST["charan"];
$nadi=$_POST["nadi"];
$gan=$_POST["gan"];
$birth_place=$_POST["birth_place"];
$birth_time=$_POST["birth_time"];
$birth_time=$_POST["birth_time"];
$mangal=$_POST["mangal"];
$gotra=$_POST["gotra"];

// Educational / Professional Details

$educational_area=$_POST["educational_area"];
$education=$_POST["education"];
$occupation=$_POST["occupation"];
$occupation_city=$_POST["occupation_city"];
$income=$_POST["income"];

// Address

$residence_add=$_POST["residence_add"];
$residence_city=$_POST["residence_city"];
$email=$_POST["email"];
$pan_no=$_POST["pan_no"];
$mobile_sms=$_POST["mobile_sms"];
$mobile_1=$_POST["mobile_1"];
$phone_1=$_POST["phone_1"];
$phone_2=$_POST["phone_2"];


//family background

$father=$_POST["father"];
$parent_fname=$_POST["parent_fname"];
$mother=$_POST["mother"];
$parent_city=$_POST["parent_city"];
$brother=$_POST["brother"];
$married_brother=$_POST["married_brother"];
$sister=$_POST["sister"];
$married_sister=$_POST["married_sister"];
$parent_occupation=$_POST["parent_occupation"];
$surname_relative=$_POST["surname_relative"];
$native_district=$_POST["native_district"];
$family_wealth=$_POST["family_wealth"];
$native_tal=$_POST["native_tal"];
$mama_surname=$_POST["mama_surname"];
$intercast=$_POST["intercast"];
$intercast_relation=$_POST["intercast_relation"];


//Expectation

$prefered_city=$_POST["prefered_city"];
$expected_mangal=$_POST["expected_mangal"];
$expected_caste=$_POST["expected_caste"];
$max_age_diff=$_POST["max_age_diff"];
$expected_min_height=$_POST["expected_min_height"];
$divorcee=$_POST["divorcee"];
$expected_occupation=$_POST["expected_occupation"];
$expected_education=$_POST["expected_education"];


if(isset($_FILES['image'])){
      $errors= array();
      $file_name = $_FILES['image']['name'];
      $file_size =$_FILES['image']['size'];
      $file_tmp =$_FILES['image']['tmp_name'];
      $file_type=$_FILES['image']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
      
      $expensions= array("jpeg","jpg","png");
      
      if(in_array($file_ext,$expensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }
      
      if($file_size > 2097152){
         $errors[]='File size must be excately 2 MB';
      }
      
      if(empty($errors)==true){
         move_uploaded_file($file_tmp,"../images/".$file_name);
         echo "Success";
      }else{
         print_r($errors);
      }


}



$query = "update members set 
`fname` = '".$fname."' , `mname` = '".$mname."', `lname` = '".$lname."', `dob` = '".$dob."', `gender` = '".$gender."', `subcast`= '".$subcast."', `marital_status`= '".$marital_status."', 
`height` = '".$height."', `weight`= '".$weight."', `blood_group` =  '".$blood_group."', `complextion` = '".$complextion."', `physical_dis`= '".$physical_dis."', `diet` = '".$diet."',
 `specify` = '".$specify."' , `spectacles` = = '".$spectacles."' , `lens` = '".$lens."', `personality` = '".$personality."',`age` = '".$age."', `rashi` = '".$rashi."', `nakshtra` = '".$nakshtra."', 
 `charan` = '".$charan."', `nadi` = '".$nadi."', `gan` = '".$gan."', `birth_place` = '".$birth_place."', `birth_time` = '".$birth_time."', `mangal` = '".$mangal."', `gotra` = '".$gotra."', 
 `educational_area` = '".$educational_area."', `education` = '".$education."', `occupation` = '".$occupation."', `occupation_city` = '".$occupation_city."', `income` = '".$income."', `residence_add` = '".$residence_add."',
 `residence_city` = '".$residence_city."', `email` = '".$email."', `pan_no` = '".$pan_no."', `mobile_sms` = '".$mobile_sms."', `mobile_1` = '".$mobile_1."', `phone_1` = '".$phone_1."', `phone_2` = '".$phone_2."', `father` = '".$father."',
 `parent_fname` = '".$parent_fname."', `mother` = '".$mother."', `parent_city` = '".$parent_city."', `brother` = '".$brother."', `married_brother` = '".$married_brother."', `sister` =  '".$sister."', `married_sister`='".$married_sister."',
 `parent_occupation` =  '".$parent_occupation."', `surname_relative`='".$surname_relative."', `native_district`='".$native_district."', `family_wealth`='".$family_wealth."', `native_tal`= '".$native_tal."',
 `mama_surname`='".$mama_surname."', `intercast`='".$intercast."', `intercast_relation`='".$intercast_relation."', `prefered_city`='".$prefered_city."', `expected_mangal`='".$expected_mangal."', `expected_caste`='".$expected_caste."', 
 `max_age_diff`='".$max_age_diff."', `expected_min_height`='".$expected_min_height."', `divorcee`='".$divorcee."', `expected_occupation`='".$expected_occupation."', `expected_education`='".$expected_education."',
 `file_name`='".$file_name."' 
 where id=".$_POST['SNK_id'];


echo $query;

$run=mysqli_query($con,$query);
	if($run)
		{
			echo"<script> alert('Register Successfully.....') </script>";
			
		}
		else
		{
			echo"<script> alert('Please Try Again........') </script>";
		}

}

?>



<form role="form" class="form-horizontal" method="post" enctype="multipart/form-data"
style="border: 1px solid #1e73be;">				
			
	<div class="col-md-12">
			
		
		
	<div id="Content" style="background-color: #f8f8f8;">
	<div class="content_wrapper clearfix">

		<!-- .sections_group -->
		<div class="sections_group">
		
			<div class="entry-content" itemprop="mainContentOfPage">
			
				
<div class="section_wrapper mcb-section-inner">

		<?php 
	$check_user="select * from members WHERE id=".$SNK_id;  
	echo $check_user;
    $run=mysqli_query($con,$check_user);  
  
    if(mysqli_num_rows($run))  
    {  
		//echo $check_user;
        while($row = mysqli_fetch_assoc($run))
		{
		
		?>		
				
				<div class="wrap mcb-wrap one  valign-top clearfix" style="">
				    <div class="mcb-wrap-inner">
				        <div class="column mcb-column one column_column  column-margin-">
							<div class="column_attr clearfix align_center" style="background-color: #6ecbf6;"><h2 style="font-family:"Lucida Grande",Verdana,Arial,Helvetica,sans-serif;margin: 2px 0px;">Personal Details</h2></div>
				        </div>
			
						<div class="column mcb-column one-third column_column  column-margin-">
							<div class="column_attr clearfix align_center" style="">
								<label style="text-align: left;">First Name*</label>
						
								<input name="fname" class="form-control" type="text" id="fname" value="<?php echo $row['fname']; ?>" maxlength="25" required="" >
							</div>
						</div>
						<div class="column mcb-column one-third column_column  column-margin-">
							<div class="column_attr clearfix align_center" style="">
							<label style="text-align: left;">Middle Name*</label>

								<input name="mname" class="form-control" type="text" id="mname" value="" maxlength="25" required="">
							</div>
						</div>
							<div class="column mcb-column one-third column_column  column-margin-">
								<div class="column_attr clearfix align_center" style="">
								<label style="text-align: left;">Last Name*</label>
					
								<input name="lname" class="form-control" type="text" id="lname" value="" maxlength="25" required="">
								</div>
							</div>
					</div>
					<input name="SNK_id" class="form-control" type="hidden" id="SNK_id" value="<?php echo $SNK_id; ?>" required="">
				</div>
				
				<div class="wrap mcb-wrap one  valign-top clearfix" style="">
					<div class="mcb-wrap-inner">
						<div class="column mcb-column one-third column_column  column-margin-">
							<div class="column_attr clearfix align_center" style="">
								<div class="form-group  col-md-6 ">
								<label style="text-align: left;">Gender*</label>
									<div class="col-md-8">
											<select class="form-control" name="gender" id="lens" onchange="gender1(this.value)" required="">
												<option value="No" selected="selected">Select</option>
												<option>Male</option>
												<option>Female</option>
											</select>
									</div>
								</div>
							</div>
						</div>
						
							<div class="column mcb-column one-third column_column  column-margin-">
								<div class="column_attr clearfix align_center" style="">
									<label style="text-align: left;">Date Of Birth*</label>
				
									<input name="dob" class="form-control" type="date" id="dob" value="" required="">
								</div>
							</div>
							<div class="column mcb-column one-third column_column  column-margin-">
								<div class="column_attr clearfix align_center" style="">
									<label style="text-align: left;">Sub cast</label>
						
									<select class="form-control" name="subcast" id="select3">
										<option value="Buddhist" selected="selected">Buddhist</option>
									</select>
								</div>
							</div>
					</div>
				</div>
				
				<div class="wrap mcb-wrap one  valign-top clearfix" style="">
					<div class="mcb-wrap-inner">
						<div class="column mcb-column one-third column_column  column-margin-">
							<div class="column_attr clearfix align_center" style="">
								<label style="text-align: left;">Marital Status</label>
			
								<select class="form-control" name="marital_status" id="marital_status" required="">
										<option  class="leftmenu" selected="selected">Unmarried Boy</option>
										<option  class="leftmenu">Unmarried Girl</option>
										<option  class="leftmenu">Divorcee Boy / Widower</option>
										<option  class="leftmenu">Divorcee Girl / Widow</option>
								</select>
							</div>
						</div>
						<div class="column mcb-column one-third column_column  column-margin-">
							<div class="column_attr clearfix align_center" style="">
								<label style="text-align: left;">Height</label>
				
									<select name="height" class="form-control" id="form_3_1-element-12">
										<option value="">Select an option</option>
										<option value="134">4ft 5in - 134cm</option>
										<option value="137">4ft 6in - 137cm</option>
										<option value="139">4ft 7in - 139cm</option>
										<option value="142">4ft 8in - 142cm</option>
										<option value="144">4ft 9in - 144cm</option>
										<option value="147">4ft 10in - 147cm</option>
										<option value="149">4ft 11in - 149cm</option>
										<option value="152">5ft - 152cm</option>
										<option value="154">5ft 1in - 154cm</option>
										<option value="157">5ft 2in - 157cm</option>
										<option value="160">5ft 3in - 160cm</option>
										<option value="162">5ft 4in - 162cm</option>
										<option value="165">5ft 5in - 165cm</option>
										<option value="167">5ft 6in - 167cm</option>
										<option value="170">5ft 7in - 170cm</option>
										<option value="172">5ft 8in - 172cm</option>
										<option value="175">5ft 9in - 175cm</option>
										<option value="177">5ft 10in - 177cm</option>
										<option value="180">5ft 11in - 180cm</option>
										<option value="182">6ft - 182cm</option>
										<option value="185">6ft 1in - 185cm</option>
										<option value="187">6ft 2in - 187cm</option>
										<option value="190">6ft 3in - 190cm</option>
										<option value="193">6ft 4in - 193cm</option>
										<option value="195">6ft 5in - 195cm</option>
										<option value="198">6ft 6in - 198cm</option>
										<option value="200">6ft 7in - 200cm</option>
										<option value="203">6ft 8in - 203cm</option>
										<option value="205">6ft 9in - 205cm</option>
										<option value="208">6ft 10in - 208cm</option>
										<option value="210">6ft 11in - 210cm</option>
										<option value="213">7ft - 213cm</option>
									</select>
							</div>
						</div>

						<div class="column mcb-column one-third column_column  column-margin-">
							<div class="column_attr clearfix align_center" style="">
								<label style="text-align: left;">Weight(kg)</label>
			
									<select class="form-control" name="weight" id="weight">
										<option value="--">N/A</option>
										<option value="30">30</option>
										<option value="31">31</option>
										<option value="32">32</option>
										<option value="33">33</option>
										<option value="34">34</option>
										<option value="35">35</option>
										<option value="36">36</option>
										<option value="37">37</option>
										<option value="38">38</option>
										<option value="39">39</option>
										<option value="40" selected="selected">40</option>
										<option value="41">41</option>
										<option value="42">42</option>
										<option value="43">43</option>
										<option value="44">44</option>
										<option value="45">45</option>
										<option value="46">46</option>
										<option value="47">47</option>
										<option value="48">48</option>
										<option value="49">49</option>
										<option value="50">50</option>
										<option value="51">51</option>
										<option value="52">52</option>
										<option value="53">53</option>
										<option value="54">54</option>
										<option value="55">55</option>
										<option value="56">56</option>
										<option value="57">57</option>
										<option value="58">58</option>
										<option value="59">59</option>
										<option value="60">60</option>
										<option value="61">61</option>
										<option value="62">62</option>
										<option value="63">63</option>
										<option value="64">64</option>
										<option value="65">65</option>
										<option value="66">66</option>
										<option value="67">67</option>
										<option value="68">68</option>
										<option value="69">69</option>
										<option value="70">70</option>
										<option value="71">71</option>
										<option value="72">72</option>
										<option value="73">73</option>
										<option value="74">74</option>
										<option value="75">75</option>
										<option value="76">76</option>
										<option value="77">77</option>
										<option value="78">78</option>
										<option value="79">79</option>
										<option value="80">80</option>
										<option value="81">81</option>
										<option value="82">82</option>
										<option value="83">83</option>
										<option value="84">84</option>
										<option value="85">85</option>
										<option value="86">86</option>
										<option value="87">87</option>
										<option value="88">88</option>
										<option value="89">89</option>
										<option value="90">90</option>
										<option value="91">91</option>
										<option value="92">92</option>
										<option value="93">93</option>
										<option value="94">94</option>
										<option value="95">95</option>
										<option value="96">96</option>
										<option value="97">97</option>
										<option value="98">98</option>
										<option value="99">99</option>
										<option value="100">100</option>
										<option value="101">101</option>
										<option value="102">102</option>
										<option value="103">103</option>
										<option value="104">104</option>
										<option value="105">105</option>
										<option value="106">106</option>
										<option value="107">107</option>
										<option value="108">108</option>
										<option value="109">109</option>
										<option value="110">110</option>
									</select>
							</div>
						</div>
					</div>
				</div>
			<div class="wrap mcb-wrap one  valign-top clearfix" style="">
			<div class="mcb-wrap-inner">
				<div class="column mcb-column one-third column_column  column-margin-">
					<div class="column_attr clearfix align_center" style="">
						<label style="text-align: left;">Blood Group</label>
						<select class="form-control" name="blood_group" id="blood_group">
							<option value="A+">A+</option>
							<option value="A-">A-</option>
							<option value="B+">B+</option>
							<option value="B-">B-</option>
							<option value="AB+">AB+</option>
							<option value="AB-">AB-</option>
							<option value="O+">O+</option>
							<option value="O-">O-</option>
							<option value="--">Don't Know</option>
						</select>
					</div>
				</div>
				
				<div class="column mcb-column one-third column_column  column-margin-">
				<div class="column_attr clearfix align_center" style="">
				<label style="text-align: left;">Complexion</label>

					<select class="form-control" name="complextion" id="select13">
					<option value="FAIR">FAIR</option>
					<option value="GORA">GORA</option>
					<option value="SAWALA">SAWALA</option>
					<option value="GAVHAL">GAVHAL</option>
					<option value="NIMGORA">NIMGORA</option>
					<option value="BLACK">BLACK</option>
					<option value="GORA,SMART">GORA,SMART</option>
					<option value="FAIR,SMART">FAIR,SMART</option>
					<option value="GAVHAL,SMART">GAVHAL,SMART</option>
					</select>
			</div>
			</div>
				<div class="column mcb-column one-third column_column  column-margin-">
					<div class="column_attr clearfix align_center" style="">
						<div class="form-group  col-md-6 ">
							<label style="text-align: left;">Diet</label>
							<div class="col-md-8">
								<select class="form-control" name="diet" id="diet">
									<option value="N/A" selected="selected">N/A</option>
									<option value="Vegetarian">Vegetarian</option>
									<option value="Non Vegetarian">Non Vegetarian</option>
								</select>
							</div>
						</div>
					</div>
				</div>
		 </div>
		</div> 
		<div class="wrap mcb-wrap one  valign-top clearfix" style="">
		<div class="mcb-wrap-inner">
			<div class="column mcb-column one-third column_column  column-margin-">
				<div class="column_attr clearfix align_center" style="">
					<div class="form-group  col-md-6 ">
							<label style="text-align: left;">Physical Disabilities</label>
							<div class="col-md-8">
							<select class="form-control" name="physical_dis" id="phydisable">
								<option value="No" selected="selected">No</option>
								<option value="Yes">Yes</option>
							</select>
							</div>
					</div>
				</div>
			</div>
		<div class="column mcb-column one-third column_column  column-margin-">
		<div class="column_attr clearfix align_center" style="">
		<div class="form-group  col-md-6 ">
				<label style="text-align: left;">If yes, pl specify</label>
				<div class="col-md-8">
				<input name="specify" class="form-control" type="text" id="nakshatra" size="60" maxlength="50">
				</div>
		</div>
		</div>
		</div>
		<div class="column mcb-column one-third column_column  column-margin-">
		<div class="column_attr clearfix align_center" style="">
		<div class="form-group  col-md-6 ">
			<label style="text-align: left;">Spectacles</label>
			<div class="col-md-8">
			<select class="form-control" name="spectacles">
			<option value="No" selected="selected">No</option>
            <option value="Yes">Yes</option>
        </select>
			</div>
		</div>
		</div>
		</div>
		</div>
		</div>
		<div class="wrap mcb-wrap one  valign-top clearfix" style="">
		<div class="mcb-wrap-inner">
		<div class="column mcb-column one-third column_column  column-margin-">
			<div class="column_attr clearfix align_center" style="">
				<div class="form-group  col-md-6 ">
				<label style="text-align: left;">Lens</label>
					<div class="col-md-8">
							<select class="form-control" name="lens" id="lens">
									 <option value="No" selected="selected">No</option>
									<option value="Yes">Yes</option>
							</select>
					</div>
				</div>

			</div>
		</div>
		<div class="column mcb-column one-third column_column  column-margin-">
			<div class="column_attr clearfix align_center" style="">
				<div class="form-group  col-md-6 ">
						<label style="text-align: left;">Personality</label>
						<div class="col-md-8">
						<input name="personality" class="form-control" type="text" id="personality" value="" maxlength="50">
						</div>
				</div>
			</div>
		</div>
		<div class="column mcb-column one-third column_column  column-margin-">
		    <div class="column_attr clearfix align_center" style="">
		    <div class="form-group  col-md-6 ">
				<label style="text-align: left;">Age*</label>
				<div class="col-md-8">
				<input name="age" class="form-control" type="text" id="age" value="" maxlength="50">
				</div>
		    </div>
		    </div>
		</div>
		
		
		</div>
	</div>
	</div>	</div>
		
		<!-- <div class="wrap mcb-wrap one  valign-top clearfix" style=""><div class="mcb-wrap-inner"><div class="column mcb-column one column_column  column-margin-"><div class="column_attr clearfix align_center" style=""><h2>Horoscop Details</h2></div></div><div class="column mcb-column one-third column_column  column-margin-"><div class="column_attr clearfix align_center" style=""><div class="form-group  col-md-6 ">
				<label style="text-align: left;">Rashi</label>
				<div class="col-md-8">
			<select class="form-control" size="1" name="rashi">
			<option value="Unspecified" selected="selected">Unspecified</option>
			<option value="Mesh">Mesh</option>
			<option value="Vrushabh">Vrushabh</option>
			<option value="mithun">Mithun</option>
			<option value="kark">Kark</option>
			<option value="sinha">Sinha</option>
			<option value="kanya">Kanya</option>
			<option value="tula">Tula</option>
			<option value="vrischik">Vrischik</option>
			<option value="dhanu">Dhanu</option>
			<option value="makar">Makar</option>
			<option value="kumbh">Kumbh</option>
			<option value="meen">Meen</option>
			</select>
				</div>
		</div></div></div><div class="column mcb-column one-third column_column  column-margin-"><div class="column_attr clearfix align_center" style=""><div class="form-group  col-md-6 ">
			<label style="text-align: left;">Nakshtra</label>
			<div class="col-md-8">
			<select class="form-control" size="1" name="nakshtra">
              <option value="Unspecified" selected="selected">Unspecified</option>
              <option value="Ashwini">Ashwini</option>
              <option value="Ardra">Ardra</option>
              <option value="Aslesha">Aslesha</option>
              <option value="Anuradha">Anuradha</option>
              <option value="Bharani">Bharani</option>
              <option value="Chitra">Chitra</option>
              <option value="Dhanishta">Dhanishta</option>
              <option value="Hasta">Hasta</option>
              <option value="Jyeshta">Jyeshta</option>
              <option value="Krittika">Krittika</option>
              <option value="Moola">Moola</option>
              <option value="Magha">Magha</option>
              <option value="Mrigasira">Mrigasira</option>
              <option value="Pushya">Pushya</option>
              <option value="Purva Phalgini">Purva Phalgini</option>
              <option value="Purva Bhadra">Purva Bhadra</option>
              <option value="Purva Shadha">Purva Shadha</option>
              <option value="Punarvasu">Punarvasu</option>
              <option value="Rohini">Rohini</option>
              <option value="Swati">Swati</option>
              <option value="Revati">Revati</option>
              <option value="Shattarka">Shattarka</option>
              <option value="Shravan">Shravan</option>
              <option value="Uttara Phalguni">Uttara Phalguni</option>
              <option value="Uttara Bhadra">Uttara Bhadra</option>
              <option value="Uttara Shadha">Uttara Shadha</option>
              <option value="Vishakha">Vishakha</option>
            </select>
			</div>
		</div></div></div><div class="column mcb-column one-third column_column  column-margin-"><div class="column_attr clearfix align_center" style=""><div class="form-group  col-md-6 ">
				<label style="text-align: left;">charan</label>
				<div class="col-md-8">
				<select class="form-control" size="1" name="charan">
				 <option value="Unspecified" selected="selected">Unspecified</option>
					<option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    </select>
				</div>
		</div></div></div></div></div><div class="wrap mcb-wrap one  valign-top clearfix" style=""><div class="mcb-wrap-inner"><div class="column mcb-column one-third column_column  column-margin-"><div class="column_attr clearfix align_center" style=""><div class="form-group  col-md-6 ">
			<label style="text-align: left;">Nadi</label>
			<div class="col-md-8">
			<select class="form-control" size="1" name="nadi">
				 <option value="Unspecified" selected="selected">Unspecified</option>
				<option value="Adhya">Adhya</option>
                    <option value="Madhya">Madhya </option>
                    <option value="Antya">Antya</option>
                    </select>
			</div>
		</div></div></div><div class="column mcb-column one-third column_column  column-margin-"><div class="column_attr clearfix align_center" style="">	 
		<div class="form-group  col-md-6 ">
				<label style="text-align: left;">Gan</label>
				<div class="col-md-8">
				<select class="form-control" size="1" name="gan">
					<option value="Unspecified" selected="selected">Unspecified</option>
					<option value="Dev Gan">Dev Gan</option>
                    <option value="Manushya Gan">Manushya Gan</option>
                    <option value="Rakshas Gan"> Rakshas Gan</option>
                    </select>
				</div>
		</div>
</div></div><div class="column mcb-column one-third column_column  column-margin-"><div class="column_attr clearfix align_center" style=""><div class="form-group  col-md-6 ">
			<label style="text-align: left;">Birth Place</label>
			<div class="col-md-8">
			<input name="birth_place" class="form-control" type="text" id="bplace2" value="" maxlength="25">
			</div>
		</div></div></div></div></div><div class="wrap mcb-wrap one  valign-top clearfix" style=""><div class="mcb-wrap-inner"><div class="column mcb-column one-third column_column  column-margin-"><div class="column_attr clearfix align_center" style=""><div class="form-group  col-md-6 ">
				<label style="text-align: left;">Birth Time</label>
				<div class="col-md-8" >
			<input name="birth_time" class="form-control" type="time" id="bplace2" value="" maxlength="25" style="width: 62%;float: left;padding: 8px;">
			</div>
				
		</div></div></div><div class="column mcb-column one-third column_column  column-margin-"><div class="column_attr clearfix align_center" style=""><div class="form-group  col-md-6 ">
			<label style="text-align: left;">Mangal</label>
			<div class="col-md-8">
			<select class="form-control" name="mangal" id="select18">
			<option value="Yes">Yes</option>
			<option value="No" selected="selected">No</option>
			<option value="Saumya">Saumya</option>
			<option value="Nirdosh">Nirdosh</option>
			<option value="Not Known">Not Known</option>
        </select>
			</div>
		</div></div></div><div class="column mcb-column one-third column_column  column-margin-"><div class="column_attr clearfix align_center" style=""><div class="form-group  col-md-6 ">
				<label style="text-align: left;">Gotra / Deva</label>
				<div class="col-md-8">
				<input name="gotra" class="form-control" type="text" id="goatra" value="" size="50" maxlength="50">
				</div>
		</div></div></div></div></div> --> 
	
		
	<div class="wrap mcb-wrap one  valign-top clearfix" style="">
		<div class="mcb-wrap-inner">
		<div class="column mcb-column one column_column  column-margin-">
		<div class="column_attr clearfix align_center" style="background-color: #6ecbf6;"><h2 style="font-family:"Lucida Grande",Verdana,Arial,Helvetica,sans-serif;margin: 2px 0px;">Educational / Professional Details</h2></div>
		</div>
		


		<div class="column mcb-column one-third column_column  column-margin-"><div class="column_attr clearfix align_center" style=""><div class="form-group  col-md-6 ">
				<label style="text-align: left;">Education Area</label>
				<div class="col-md-8">
				<select class="form-control" name="educational_area" id="select">
            <option value="GRADUATE">12th to Graduate</option>
			<option value="DOUBLE GRADUATE">Post - Graduate</option>
			<option value="doctor">Doctor</option>
			<option value="engineer">Engineer</option>
			</select>  
				</div>
		</div>
		</div>
		</div>
			<div class="column mcb-column one-third column_column  column-margin-">
				<div class="column_attr clearfix align_center" style="">
					<div class="form-group  col-md-6 ">
						<label style="text-align: left;">Education</label>
						<div class="col-md-8">
							<input name="education" class="form-control" type="text" id="education" value="" maxlength="75">
						</div>
					</div>
				</div>
			</div>
			<div class="column mcb-column one-third column_column  column-margin-">
				<div class="column_attr clearfix align_center" style="">
					<div class="form-group  col-md-6 ">
							<label style="text-align: left;">Occupation</label>
								<div class="col-md-8">
								<input name="occupation" class="form-control" type="text" id="occupation2" value="" maxlength="75">
								</div>
					</div>
				</div>
			</div>
		</div>	
    </div>


<div class="wrap mcb-wrap one  valign-top clearfix" style="">
	<div class="mcb-wrap-inner">
		<div class="column mcb-column one-third column_column  column-margin-">
			<div class="column_attr clearfix align_center" style="">
				<div class="form-group  col-md-6 ">
					<label style="text-align: left;">Annual Income</label>
					<div class="col-md-8">
						<input name="income" type="text" class="form-control" id="income3" value="" maxlength="20">
					<!--	<select class="form-control" name="income" id="income3" type="text">
							<option value="">Select Income</option>
							<option value="80,000-1,00,000">80,000-1,00,000</option>
							<option value="1,00,000-3,00,000">1,00,000-3,00,000</option>
							<option value="3,00,000-5,00,000">3,00,000-5,00,000</option>
							<option value="5,00,000-Above">5,00,000-Above</option>
						</select> -->
					
					</div>
				</div>
			</div>
		</div>
		<div class="column mcb-column one-third column_column  column-margin-">
			<div class="column_attr clearfix align_center" style="">
				<div class="form-group  col-md-6 ">
					<label style="text-align: left;">Occupation City/Country</label>
						<div class="col-md-8">
							<select class="form-control" name="occupation_city" id="city2">
							<option value="">Not Specific</option>
                            <option value="A.NAGAR">A.NAGAR</option>
                            <option value="ADILABAD">ADILABAD</option>
                            <option value="AHMEDABAD">AHMEDABAD</option>
                            <option value="AKOLA">AKOLA</option>
                            <option value="AMRAVATI">AMRAVATI</option>
                            <option value="ANDHRA PRADESH">ANDHRA PRADESH</option>
                            <option value="ANKALESHWAR">ANKALESHWAR</option>
                            <option value="ASHOK NAGAR">ASHOK NAGAR</option>
                            <option value="ASSAM">ASSAM</option>
                            <option value="AURANGABAD">AURANGABAD</option>
                            <option value="AUSTRALIA">AUSTRALIA</option>
                            <option value="AUSTRIA">AUSTRIA</option>
                            <option value="BAGALKOT">BAGALKOT</option>
                            <option value="BAHRAIN">BAHRAIN</option>
                            <option value="BANGALORE">BANGALORE</option>
                            <option value="BARODA">BARODA</option>
                            <option value="BEED">BEED</option>
                            <option value="BELGAUM">BELGAUM</option>
                            <option value="BETUL">BETUL</option>
                            <option value="BHANDARA">BHANDARA</option>
                            <option value="BHARUCH">BHARUCH</option>
                            <option value="BHILAI">BHILAI</option>
                            <option value="BHOPAL">BHOPAL</option>
                            <option value="BIDAR">BIDAR</option>
                            <option value="BIHAR">BIHAR</option>
                            <option value="BIJAPUR">BIJAPUR</option>
                            <option value="BILASPUR">BILASPUR</option>
                            <option value="BULDANA">BULDANA</option>
                            <option value="BURHANPUR">BURHANPUR</option>
                            <option value="CALICUT">CALICUT</option>
                            <option value="CANADA">CANADA</option>
                            <option value="CHANDIGARH">CHANDIGARH</option>
                            <option value="CHANDRAPUR">CHANDRAPUR</option>
                            <option value="CHATTISGARH">CHATTISGARH</option>
                            <option value="CHENNAI">CHENNAI</option>
                            <option value="CHHINDWARA">CHHINDWARA</option>
                            <option value="CHINA">CHINA</option>
                            <option value="CHITTORGARH">CHITTORGARH</option>
                            <option value="COIMBATORE">COIMBATORE</option>
                            <option value="DANDELI">DANDELI</option>
                            <option value="DAVANGERE">DAVANGERE</option>
                            <option value="DEHRADUN">DEHRADUN</option>
                            <option value="DELHI">DELHI</option>
                            <option value="DEWAS">DEWAS</option>
                            <option value="DHAMTARI">DHAMTARI</option>
                            <option value="DHAR">DHAR</option>
                            <option value="DHARWAD">DHARWAD</option>
                            <option value="DHULE">DHULE</option>
                            <option value="DUBAI">DUBAI</option>
                            <option value="DURG">DURG</option>
                            <option value="FRANCE">FRANCE</option>
                            <option value="GADCHIROLI">GADCHIROLI</option>
                            <option value="GANDHINAGAR">GANDHINAGAR</option>
                            <option value="GERMANY">GERMANY</option>
                            <option value="GHAZIABAD">GHAZIABAD</option>
                            <option value="GOA">GOA</option>
                            <option value="GOKAK">GOKAK</option>
                            <option value="GONDIA">GONDIA</option>
                            <option value="GUJARAT">GUJARAT</option>
                            <option value="GULBARGA">GULBARGA</option>
                            <option value="GUNTUR">GUNTUR</option>
                            <option value="GUWAHATI">GUWAHATI</option>
                            <option value="GWALIOR">GWALIOR</option>
                            <option value="HARIHAR">HARIHAR</option>
                            <option value="HARYANA">HARYANA</option>
                            <option value="HINGOLI">HINGOLI</option>
                            <option value="HONGKONG">HONGKONG</option>
                            <option value="HUBLI">HUBLI</option>
                            <option value="HYDERABAD">HYDERABAD</option>
                            <option value="INDORE">INDORE</option>
                            <option value="JABALPUR">JABALPUR</option>
                            <option value="JAIPUR">JAIPUR</option>
                            <option value="JALGAON">JALGAON</option>
                            <option value="JALNA">JALNA</option>
                            <option value="JAMKHANDI">JAMKHANDI</option>
                            <option value="JAMNAGAR">JAMNAGAR</option>
                            <option value="JAMSHEDPUR">JAMSHEDPUR</option>
                            <option value="JAPAN">JAPAN</option>
                            <option value="KARAD">KARAD</option>
                            <option value="KARWAR">KARWAR</option>
                            <option value="KERALA">KERALA</option>
                            <option value="KHANDWA">KHANDWA</option>
                            <option value="KOLHAPUR">KOLHAPUR</option>
                            <option value="KOLKATA">KOLKATA</option>
                            <option value="KOREA">KOREA</option>
                            <option value="KURNOOL">KURNOOL</option>
                            <option value="LATUR">LATUR</option>
                            <option value="MALYSIA">MALYSIA</option>
                            <option value="MANGALORE">MANGALORE</option>
                            <option value="MANIPAL">MANIPAL</option>
                            <option value="MEDAK">MEDAK</option>
                            <option value="MUDHOL">MUDHOL</option>
                            <option value="MUMBAI">MUMBAI</option>
                            <option value="MYSORE">MYSORE</option>
                            <option value="NAGPUR">NAGPUR</option>
                            <option value="NANDED">NANDED</option>
                            <option value="NANDURBAR">NANDURBAR</option>
                            <option value="NASHIK">NASHIK</option>
                            <option value="NAVI MUMBAI">NAVI MUMBAI</option>
                            <option value="NETHERLAND">NETHERLAND</option>
                            <option value="NEW ZEALAND">NEW ZEALAND</option>
                            <option value="NIZAMABAD">NIZAMABAD</option>
                            <option value="NORWAY">NORWAY</option>
                            <option value="OMAN">OMAN</option>
                            <option value="OSMANABAD">OSMANABAD</option>
                            <option value="PALGHAR">PALGHAR</option>
                            <option value="PANVEL">PANVEL</option>
                            <option value="PARBHANI">PARBHANI</option>
                            <option value="PUNE">PUNE</option>
                            <option value="RAICHUR">RAICHUR</option>
                            <option value="RAIGAD">RAIGAD</option>
                            <option value="RAIPUR">RAIPUR</option>
                            <option value="RAJASTHAN">RAJASTHAN</option>
                            <option value="RANCHI">RANCHI</option>
                            <option value="RATLAM">RATLAM</option>
                            <option value="RATNAGIRI">RATNAGIRI</option>
                            <option value="RUSSIA">RUSSIA</option>
                            <option value="S.AFRICA">S.AFRICA</option>
                            <option value="SANGLI">SANGLI</option>
                            <option value="SATARA">SATARA</option>
                            <option value="SAUDI ARABIA">SAUDI ARABIA</option>
                            <option value="SECUNDERABAD">SECUNDERABAD</option>
                            <option value="SHRILANKA">SHRILANKA</option>
                            <option value="SILVASSA">SILVASSA</option>
                            <option value="SINDHUDURG">SINDHUDURG</option>
                            <option value="SINGAPORE">SINGAPORE</option>
                            <option value="SOLAPUR">SOLAPUR</option>
                            <option value="SPAIN">SPAIN</option>
                            <option value="SURAT">SURAT</option>
                            <option value="SWEDEN">SWEDEN</option>
                            <option value="TAIWAN">TAIWAN</option>
                            <option value="TAMILNADU">TAMILNADU</option>
                            <option value="THANE">THANE</option>
                            <option value="UAE">UAE</option>
                            <option value="UJJAIN">UJJAIN</option>
                            <option value="UK">UK</option>
                            <option value="USA">USA</option>
                            <option value="UTTAR PRADESH">UTTAR PRADESH</option>
                            <option value="VIDISHA">VIDISHA</option>
                            <option value="VIJAPUR">VIJAPUR</option>
                            <option value="VIZAG">VIZAG</option>
                            <option value="WARDHA">WARDHA</option>
                            <option value="WASHIM">WASHIM</option>
                            <option value="YAVATMAL">YAVATMAL</option>
							</select>
						</div>
				</div>
			</div>
		</div>
	</div>
</div>
		</div>
		
	<div class="wrap mcb-wrap one  valign-top clearfix" style="">
		<div class="mcb-wrap-inner">
				<div class="column mcb-column one column_column  column-margin-">
					<div class="column_attr clearfix align_center" style="background-color: #6ecbf6;"><h2 style="font-family:"Lucida Grande",Verdana,Arial,Helvetica,sans-serif;margin: 2px 0px;">Address</h2></div>
				</div>
				
				
		
			<div class="column mcb-column one-fourth column_column  column-margin-">
				<div class="column_attr clearfix align_center" style="">
					<div class="form-group col-xs-12">
							<label style="text-align: left;">Residence Address</label>
							<div class="col-md-8">
								<textarea class="form-control" name="residence_add" cols="25" rows="5" id="textarea"></textarea>
							</div>
					</div>
				</div>
			</div>
			
			<div class="column mcb-column one-fourth column_column  column-margin-">
				<div class="column_attr clearfix align_center" style="">
					<div class="form-group  col-md-6 ">
					<label style="text-align: left;">City</label>
						<div class="col-md-8">
						<input name="residence_city" class="form-control" type="text" id="physic" value="" maxlength="20">
						</div>
					</div>
				</div>
			</div>
			
			<div class="column mcb-column one-fourth column_column  column-margin-">
				<div class="column_attr clearfix align_center" style="">
					<div class="form-group  col-md-6 ">
						<label style="text-align: left;">Email Id*</label>
						<div class="col-md-8">
						<input name="email" class="form-control" type="text" id="email2" value="" size="30" maxlength="100" required />
						</div>
					</div>
				</div>
			</div>
			
			<div class="column mcb-column one-fourth column_column  column-margin-">
				<div class="column_attr clearfix align_center" style="">
					<div class="form-group  col-md-6 ">
					<label style="text-align: left;">PAN / Adhar/ Driving License / Passport No</label>
						<div class="col-md-8">
						<input name="pan_no" class="form-control" type="text" id="physic" value="" maxlength="20">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
		
		
		
		
	<div class="wrap mcb-wrap one  valign-top clearfix" style="">
		<div class="mcb-wrap-inner">
			<div class="column mcb-column one-fourth column_column  column-margin-">
				<div class="column_attr clearfix align_center" style="">
					<div class="form-group  col-md-6 ">
							<label style="text-align: left;">Mobile for SMS alert*</label>
								<div class="col-md-8">
								<input name="mobile_sms" class="form-control" type="text" id="phone2" value="" maxlength="11" required />
								</div>
					</div>
				</div>
			</div>
			<div class="column mcb-column one-fourth column_column  column-margin-">
				<div class="column_attr clearfix align_center" style="">
					<div class="form-group  col-md-6 ">
						<label style="text-align: left;">Mobile - II</label>
						<div class="col-md-8"><input name="mobile_1" class="form-control" type="text" id="zipcode2" value="" maxlength="11">
						</div>
					</div>
				</div>
			</div>
			<div class="column mcb-column one-fourth column_column  column-margin-">
				<div class="column_attr clearfix align_center" style="">
					<div class="form-group  col-md-6 ">
							<label style="text-align: left;">Phone I</label>
							<div class="col-md-8">
								<input name="phone_1" class="form-control" type="text" id="mobile2" value="" maxlength="15">
							</div>
					</div>
				</div>
			</div>
			<div class="column mcb-column one-fourth column_column  column-margin-">
				<div class="column_attr clearfix align_center" style="">
					<div class="form-group  col-md-6 ">
						<label style="text-align: left;">Phone - II</label>
							<div class="col-md-8">
							<input name="phone_2" class="form-control" type="text" id="mobile2" value="" maxlength="15">
							</div>
					</div>
				</div>
			</div>
		</div>
	</div>
		
<!-- </div> -->		
		
		
	<div class="wrap mcb-wrap one  valign-top clearfix" style="">
		<div class="mcb-wrap-inner">
			<div class="column mcb-column one column_column  column-margin-">
				<div class="column_attr clearfix align_center" style="background-color: #6ecbf6;"><h2 style="font-family:"Lucida Grande",Verdana,Arial,Helvetica,sans-serif;margin: 2px 0px;">Family Background</h2></div>
			</div>
			
			
			<div class="column mcb-column one-third column_column  column-margin-">
				<div class="column_attr clearfix align_center" style="">
					<label style="text-align: left;">Father</label>        
						<select class="form-control" name="father" id="select20">
							<option value="Yes" selected="selected">Yes</option>
							<option value="No">No</option>
						</select>
				</div>
			</div>
		
				<div class="column mcb-column one-third column_column  column-margin-">
					<div class="column_attr clearfix align_center" style="">
						<label style="text-align: left;">Parents Fullname</label>
						<input class="form-control" name="parent_fname" type="text" id="parent_fullname2" value="">
					</div>
				</div>
				<div class="column mcb-column one-third column_column  column-margin-">
					<div class="column_attr clearfix align_center" style="">
						<label style="text-align: left;">Mother</label>      
						<select class="form-control" name="mother" id="select19">
							<option value="Yes" selected="selected">Yes</option>
							<option value="No">No</option>
						</select>
					</div>
				</div>
		</div>
	</div>

			<div class="wrap mcb-wrap one  clearfix" style="">
				<div class="mcb-wrap-inner">
					<div class="column mcb-column one-third column_column  column-margin-">
						<div class="column_attr clearfix align_center" style=""><label style="text-align: left;">Parents Resident City </label> 
						<input class="form-control" name="parent_city" type="text" id="parent_resident2" value="">
						</div>
					</div>
					<div class="column mcb-column one-third column_column  column-margin-">
						<div class="column_attr clearfix align_center" style=""> <label style="text-align: left;">Brothers</label>      
							<select class="form-control" name="brother" id="brother">
								<option value="0" selected="selected">0</option>
								<option value="1">1</option>
								<option value="2">2</option>
								<option value="3">3</option>
								<option value="4">4</option>
								<option value="5">5</option>
								<option value="6">6</option>
								<option value="7">7</option>
								<option value="8">8</option>
								<option value="9">9</option>
								<option value="10">10</option>
							</select>
						</div>
					</div>
					
					<div class="column mcb-column one-third column_column  column-margin-">
						<div class="column_attr clearfix align_center" style="">
							<label style="text-align: left;">Married Brothers </label>
		   
							<select class="form-control" name="married_brother" id="mbrother" onchange="checkinout(this,'brother');">
								<option value="0" selected="selected">0</option>
								<option value="1">1</option>
								<option value="2">2</option>
								<option value="3">3</option>
								<option value="4">4</option>
								<option value="5">5</option>
								<option value="6">6</option>
								<option value="7">7</option>
								<option value="8">8</option>
								<option value="9">9</option>
								<option value="10">10</option>
							</select>
			
						</div>
					</div>
				</div>
			</div>				

			<div class="wrap mcb-wrap one  valign-top clearfix" style="">
				<div class="mcb-wrap-inner"><div class="column mcb-column one-third column_column  column-margin-">
					<div class="column_attr clearfix align_center" style="">
						<label style="text-align: left;">Sisters</label>
						<div class="col-md-3" height="20" align="left" valign="middle">
							<select class="form-control" name="sister" id="sister">
								<option value="0" selected="selected">0</option>
								<option value="1">1</option>
								<option value="2">2</option>
								<option value="3">3</option>
								<option value="4">4</option>
								<option value="5">5</option>
								<option value="6">6</option>
								<option value="7">7</option>
								<option value="8">8</option>
								<option value="9">9</option>
								<option value="10">10</option>
							</select>
						</div>

					</div>
				</div>
				<div class="column mcb-column one-third column_column  column-margin-">
					<div class="column_attr clearfix align_center" style="">
						<label style="text-align: left;">Married Sisters</label>
						<div class="col-md-3" height="20" align="left" valign="middle">
							<select class="form-control" name="married_sister" id="msister" onchange="checkinout(this,'sister');">
								<option value="0" selected="selected">0</option>
								<option value="1">1</option>
								<option value="2">2</option>
								<option value="3">3</option>
								<option value="4">4</option>
								<option value="5">5</option>
								<option value="6">6</option>
								<option value="7">7</option>
								<option value="8">8</option>
								<option value="9">9</option>
								<option value="10">10</option>
							</select>
						</div>
					</div>
				</div>
					<div class="column mcb-column one-third column_column  column-margin-">
						<div class="column_attr clearfix align_center" style="">
							<label style="text-align: left;">Parents Occupation</label>
							<div class="col-md-3" height="20" align="left">
								<input class="form-control" name="parent_occupation" type="text" id="poccupation" value="" maxlength="75">
							</div>
						</div>
					</div>
				</div>
			</div>




	<div class="wrap mcb-wrap one  valign-top clearfix" style="">

		<div class="mcb-wrap-inner">
			<div class="column mcb-column one-third column_column  column-margin-">
				<div class="column_attr clearfix align_center" style="">
					<label style="text-align: left;">Surnames of Relatives</label>
					<div class="col-md-3" height="20" align="left">
					<textarea name="surname_relative" cols="25" rows="5" id="textarea8"></textarea>
					</div>
				</div>
			</div>
				<div class="column mcb-column one-third column_column  column-margin-">
					<div class="column_attr clearfix align_center" style=""> <label style="text-align: left;">Native District</label>
						<div class="col-md-3" height="20" align="left" valign="middle">
							<select class="form-control" name="native_district" id="native_place2">
					            <option value="">Not Specific</option>							
								<option value="A.NAGAR">A.NAGAR</option>								
								<option value="ADILABAD">ADILABAD</option>								
								<option value="AKOLA">AKOLA</option>								
								<option value="AMRAVATI">AMRAVATI</option>								
								<option value="ASHOK NAGAR">ASHOK NAGAR</option>								
								<option value="AURANGABAD">AURANGABAD</option>								
								<option value="BAGALKOT">BAGALKOT</option>								
								<option value="BANGALORE">BANGALORE</option>								
								<option value="BARODA">BARODA</option>								
								<option value="BEED">BEED</option>								
								<option value="BELGAUM">BELGAUM</option>								
								<option value="BETUL">BETUL</option>								
								<option value="BHANDARA">BHANDARA</option>								
								<option value="BHOPAL">BHOPAL</option>								
								<option value="BIDAR">BIDAR</option>							
								<option value="BIJAPUR">BIJAPUR</option>								
								<option value="BULDANA">BULDANA</option>								
								<option value="BURHANPUR">BURHANPUR</option>								
								<option value="CHANDRAPUR">CHANDRAPUR</option>								
								<option value="CHHATISGARH">CHHATISGARH</option>								
								<option value="CHHINDWARA">CHHINDWARA</option>								
								<option value="DEWAS">DEWAS</option>								
								<option value="DHAMTARI">DHAMTARI</option>								
								<option value="DHAR">DHAR</option>								
								<option value="DHARWAD">DHARWAD</option>								
								<option value="DHULE">DHULE</option>								
								<option value="GADCHIROLI">GADCHIROLI</option>								
								<option value="GOA">GOA</option>								
								<option value="GOKAK">GOKAK</option>								
								<option value="GONDIA">GONDIA</option>								
								<option value="GULBARGA">GULBARGA</option>								
								<option value="GWALIOR">GWALIOR</option>								
								<option value="HINGOLI">HINGOLI</option>								
								<option value="HUBLI">HUBLI</option>								
								<option value="INDORE">INDORE</option>								
								<option value="JABALPUR">JABALPUR</option>								
								<option value="JALGAON">JALGAON</option>								
								<option value="JALNA">JALNA</option>								
								<option value="JAMKHANDI">JAMKHANDI</option>								
								<option value="KARAD">KARAD</option>								
								<option value="KARWAR">KARWAR</option>								
								<option value="KHANDWA">KHANDWA</option>								
								<option value="KOLHAPUR">KOLHAPUR</option>								
								<option value="KURNOOL">KURNOOL</option>							
								<option value="LATUR">LATUR</option>								
								<option value="MUDHOL">MUDHOL</option>								
								<option value="MUMBAI">MUMBAI</option>								
								<option value="MYSORE">MYSORE</option>								
								<option value="NAGPUR">NAGPUR</option>								
								<option value="NANDED">NANDED</option>								
								<option value="NANDURBAR">NANDURBAR</option>								
								<option value="NASHIK">NASHIK</option>								
								<option value="NAVI MUMBAI">NAVI MUMBAI</option>								
								<option value="NIZAMABAD">NIZAMABAD</option>								
								<option value="OSMANABAD">OSMANABAD</option>								
								<option value="PALGHAR">PALGHAR</option>								
								<option value="PARBHANI">PARBHANI</option>								
								<option value="PUNE">PUNE</option>								
								<option value="RAICHUR">RAICHUR</option>								
								<option value="RAIGAD">RAIGAD</option>								
								<option value="RAIPUR">RAIPUR</option>								
								<option value="RATNAGIRI">RATNAGIRI</option>								
								<option value="SANGLI">SANGLI</option>								
								<option value="SATARA">SATARA</option>								
								<option value="SILVASSA">SILVASSA</option>								
								<option value="SINDHUDURG">SINDHUDURG</option>								
								<option value="SOLAPUR">SOLAPUR</option>								
								<option value="SURAT">SURAT</option>								
								<option value="THANE">THANE</option>								
								<option value="UJJAIN">UJJAIN</option>								
								<option value="VIJAPUR">VIJAPUR</option>								
								<option value="WARDHA">WARDHA</option>								
								<option value="WASHIM">WASHIM</option>								
								<option value="YAVATMAL">YAVATMAL</option>
							</select>
						</div>
					</div>
				</div>
					<div class="column mcb-column one-third column_column  column-margin-">
						<div class="column_attr clearfix align_center" style="">
							<label style="text-align: left;">Family Wealth </label>
							<div class="col-md-3" height="20" align="left" valign="middle">
							<input class="form-control" name="family_wealth" type="text" id="estate2" value="" size="40">
							</div>
						</div>
					</div>
		</div>
	</div>		
		
	<div class="wrap mcb-wrap one  valign-top clearfix" style="">
		<div class="mcb-wrap-inner">
					<div class="column mcb-column one-fourth column_column  column-margin-">
						<div class="column_attr clearfix align_center" style="">
							<label style="text-align: left;">Native Taluka, if any </label>
							<div class="col-md-3" height="20" align="left" valign="middle">
							<input class="form-control" name="native_tal" type="text" id="taluka" value="" size="40" maxlength="20">
							</div>
						</div>
					</div>
					<!--<div class="column mcb-column one-fourth column_column  column-margin-"><div class="column_attr clearfix align_center" style=""><label style="text-align: left;">Mama's surname / Place
					</label>

				<div class="col-md-3" height="20" align="left" valign="middle">
				<input class="form-control" name="mama_surname" type="text" id="mama" value="" maxlength="50"></div></div></div> -->
			<div class="column mcb-column one-fourth column_column  column-margin-">
				<div class="column_attr clearfix align_center" style="">
					<label style="text-align: left;">Any Intercast marriage in family</label>
					<div class="col-md-3" height="20" valign="middle">
						<select class="form-control" name="intercast" id="intercast" onchange="show_row(this);">
							<option value="No" selected="selected">No</option>
							<option value="Yes">Yes</option>
						</select>		
					</div>
				</div>
			</div>
		
			<div class="column mcb-column one-fourth column_column  column-margin-">
				<div class="column_attr clearfix align_center" style="">
					<label style="text-align: left;">If yes (Relation/Caste)</label>
					<div class="col-md-3" height="20">
					<input class="form-control" name="intercast_relation" type="text" id="intercast_if" value="" size="30" maxlength="25">
					</div>
				</div>
			</div>
		</div>
	</div>
		
<!-- </div>	-->	
		
		
		
		
	<div class="wrap mcb-wrap one  valign-top clearfix" style="">
		<div class="mcb-wrap-inner">
				<div class="column mcb-column one column_column  column-margin-">
					<div class="column_attr clearfix align_center" style="background-color: #6ecbf6;"><h2 style="font-family:"Lucida Grande",Verdana,Arial,Helvetica,sans-serif;margin: 2px 0px;">Expectation</h2></div>
				</div>
				

				
				<div class="column mcb-column one-third column_column  column-margin-">
					<div class="column_attr clearfix align_center" style="">
						<label style="text-align: left;"> Preferred cities</label>
						<div class="col-md-3" height="20" align="left" valign="middle">
							<input class="form-control" name="prefered_city" type="text" id="pref_city" value="" size="30" maxlength="100">
						</div>
					</div>
				</div>
						 <!--<div class="column mcb-column one-third column_column  column-margin-"><div class="column_attr clearfix align_center" style=""><label style="text-align: left;"> Mangal </label> 

						 <div class="col-md-3" height="20" align="left" valign="middle">
						 <select class="form-control" name="expected_mangal" id="select9"> 

						 <option value="Yes">Yes</option> 

						 <option value="No" selected="selected">No</option> 

						 <option value="Saumya">Saumya</option> 

						 <option value="Nirdosh">Nirdosh</option> 

						 <option value="Doesn't Matter">Doesn't Matter</option> 

						 </select></div></div></div> -->
			<div class="column mcb-column one-third column_column  column-margin-">
				<div class="column_attr clearfix align_center" style="">
					<label style="text-align: left;"> Expected Caste </label> 

					<div class="col-md-3" height="20" align="left" valign="middle">
					<select class="form-control" name="expected_caste" id="exp_cast">
						<option value="Buddhist" selected="selected">Buddhist</option>
					</select>
					</div>
				</div>
			</div>
		</div>
	</div>
 
 
 
 
	 <div class="wrap mcb-wrap one  valign-top clearfix" style="">
		<div class="mcb-wrap-inner">
			<div class="column mcb-column one-third column_column  column-margin-">
				<div class="column_attr clearfix align_center" style="">
					<label style="text-align: left;">Max Age Difference </label>
					<div class="col-md-3" height="20" align="left" valign="middle">
						<select class="form-control" name="max_age_diff" id="age_diff">
								 <option value="0">0</option>
								 <option value="1">1</option>
								 <option value="2">2</option>
								 <option value="3">3</option>
								 <option value="4">4</option>
								 <option value="5">5</option>
								 <option value="6">6</option>
								 <option value="7">7</option>
								 <option value="8">8</option>
								 <option value="9">9</option>
								 <option value="10">10</option>
								 <option value="11">11</option>
								 <option value="12">12</option>
								 <option value="13">13</option>
								 <option value="14">14</option>
						</select>
					</div>
				</div>
			</div>
	 <div class="column mcb-column one-third column_column  column-margin-">
		<div class="column_attr clearfix align_center" style="">
			<label style="text-align: left;">Expected Min Height </label> 
				<select name="expected_min_height" class="form-control" id="form_3_1-element-12">
					<option value="">Select an option</option>
					<option value="134">4ft 5in - 134cm</option>
					<option value="137">4ft 6in - 137cm</option>
					<option value="139">4ft 7in - 139cm</option>
					<option value="142">4ft 8in - 142cm</option>
					<option value="144">4ft 9in - 144cm</option>
					<option value="147">4ft 10in - 147cm</option>
					<option value="149">4ft 11in - 149cm</option>
					<option value="152">5ft - 152cm</option>
					<option value="154">5ft 1in - 154cm</option>
					<option value="157">5ft 2in - 157cm</option>
					<option value="160">5ft 3in - 160cm</option>
					<option value="162">5ft 4in - 162cm</option>
					<option value="165">5ft 5in - 165cm</option>
					<option value="167">5ft 6in - 167cm</option>
					<option value="170">5ft 7in - 170cm</option>
					<option value="172">5ft 8in - 172cm</option>
					<option value="175">5ft 9in - 175cm</option>
					<option value="177">5ft 10in - 177cm</option>
					<option value="180">5ft 11in - 180cm</option>
					<option value="182">6ft - 182cm</option>
					<option value="185">6ft 1in - 185cm</option>
					<option value="187">6ft 2in - 187cm</option>
					<option value="190">6ft 3in - 190cm</option>
					<option value="193">6ft 4in - 193cm</option>
					<option value="195">6ft 5in - 195cm</option>
					<option value="198">6ft 6in - 198cm</option>
					<option value="200">6ft 7in - 200cm</option>
					<option value="203">6ft 8in - 203cm</option>
					<option value="205">6ft 9in - 205cm</option>
					<option value="208">6ft 10in - 208cm</option>
					<option value="210">6ft 11in - 210cm</option>
					<option value="213">7ft - 213cm</option>
				</select> 
		</div>
	 </div>
	 
			<div class="column mcb-column one-third column_column  column-margin-">
				<div class="column_attr clearfix align_center" style="">
					<label style="text-align: left;"> Divorcee </label> 
						<div class="col-md-3">
							<select class="form-control" name="divorcee" id="lens">
								 <option value="No" selected="selected">No</option>
								 <option value="Yes">Yes</option>
							</select>
						</div>
				</div>
			</div>
		</div>
	</div>
				
				
				
	<div class="wrap mcb-wrap one  valign-top clearfix" style="">
		<div class="mcb-wrap-inner">
			<div class="column mcb-column one-second column_column  column-margin-">
				<div class="column_attr clearfix align_center" style="">
					<label style="text-align: left;">Expected Occupation &amp; Income per Annum</label> 
					<div class="col-md-3" height="20" align="left" valign="top">
						<textarea class="form-control" name="expected_occupation" cols="25" rows="5" id="occupation_expect"></textarea>
					</div>
				</div>
			</div>
			<div class="column mcb-column one-second column_column  column-margin-">
				<div class="column_attr clearfix align_center" style="">
					<label style="text-align: left;">Education</label>
					<div class="col-md-3" height="20" align="left" valign="top">
					<textarea class="form-control" name="expected_education" rows="5" id="education_expect"> </textarea> </div>
				</div>
			</div>
 
			<div class="column mcb-column one-fourth column_column  column-margin-">Captcha
				<div class="column_attr clearfix align_center" style="">
					<div class="col-md-3" height="20" colspan="4" align="left" valign="top" id="imgparent">
						<div id="imgdiv"><img id="img" src="../captcha.php"></div>
						<img id="reload" src="../reload.png">
					</div>
				</div>
			</div>
		
			<div class="column mcb-column one-fourth column_column  column-margin-">
				<div class="column_attr clearfix align_center" style="">
					<div class="col-md-3" height="20" align="left" valign="top"> 
					<input class="form-control" id="captcha1" name="captcha" type="text" ize="30" maxlength="100" onblur="verifycapcha()" required="">
					</div>
				</div>
			</div>
 
 
	 <div class="column mcb-column one-fourth column_column  column-margin-">
		<div class="column_attr clearfix align_center" style="">
			<div class="col-md-3" height="20" colspan="4" align="left" valign="top" id="preview">
	 Upload your profile picture :<br/><h5 style="color: #551a8b;">File size less than 2 MB</h5></div>        
		</div>
	</div>
			<div class="column mcb-column one-fourth column_column  column-margin-">
				<div class="column_attr clearfix align_center" style=""> 
					<div class="col-md-3" height="20" align="left" valign="top">
					<input type="file" class="form-control" id="images" name="multiple_images[]" onchange="preview_images();" multiple/> 
					</div>
				</div>
			</div>
 
		 <div class="column mcb-column one-fourth column_column  column-margin-" style="display: none;">
				<div class="column_attr clearfix align_center" style=""> 

				 <div  id="image_preview" style="width:100px;"></div>
				 
				 </div>
		 </div>
 
		</div>
	</div>
	 
 </div>	
</div>
</div>
<!--<div class="column mcb-column one column_column  column-margin-">
		 <div class="column_attr clearfix align_center" style=""><center class=""><button type="submit" class="btn btn-primary btn-lg" name="saveregister">Register</button></center>
		 </div>
	 </div> -->
	 </div>
	 </div>
	 </div>
	 </div>
	 

	 <?php 
		}
	}
	 ?>
	 
<div class="section the_content no_content">
<div class="section_wrapper" style="background-color: #f8f8f8;"><div class="the_content_wrapper">
    
 <div class="column mcb-column one column_column  column-margin-">
		 <div class="column_attr clearfix align_center" style=""><center class=""><button type="submit" class="btn btn-primary btn-lg" name="saveregister">Register</button></center>
		 </div>
	 </div>
    
</div>
</div>
</div>			






	
				<div class="section section-page-footer">
					<div class="section_wrapper clearfix">
					
						<div class="column one page-pager">
													</div>
						
					</div>
				</div>
				
			</div>
			
				
		</div>
		
		<!-- .four-columns - sidebar -->
		
	</div>
		
		
		
		
		</form>
		
		
		
		
		
		

<script>
function gender1(val)
    {
(function($) {
        if(val != '')
        {
            if(val == 'Male')
            {
                txt = "";
               	txt += ' <option class="leftmenu" selected="selected">Unmarried Boy</option>';
				
	txt += ' <option class="leftmenu">Divorcee Boy / Widower</option>';
				
                
                $('#marital_status').html(txt);
            }
            else if(val == 'Female')
            {
                txt = "";
               	
	txt += ' <option class="leftmenu">Unmarried Girl</option>';
				
	txt += ' <option class="leftmenu">Divorcee Girl / Widow</option>';
                
                $('#marital_status').html(txt);
            }

        }
})( jQuery );
    } 
	
	
	
	function preview_images() 
{
	(function($) {
 var total_file=document.getElementById("images").files.length;
 for(var i=0;i<total_file;i++)
 {
  $('#image_preview').append("<div class='col-md-3'><img class='img-responsive' src='"+URL.createObjectURL(event.target.files[i])+"'></div>");
 }
 })( jQuery );
}
	
	
	
</script>

<?php 
include('footer.php');

}
else if(!$_SESSION['SNK_email'])  
{  
    header("Location: login.php");//redirect to login page to secure the welcome page without login access.  
}  
?>