<?php  
session_start();
?><html>  
<head lang="en">  
    <meta charset="UTF-8">  
    <link type="text/css" rel="stylesheet" href="bootstrap-3.2.0-dist\css\bootstrap.css">  
    <title>Admin Login</title>  
</head>  
<style>  
    .login-panel {  
        margin-top: 150px;  
  
</style>  
  
<body>  
 
<?php  

include 'config.php'; 
//include("customer/Db_conection.php");  
  
if(isset($_POST['admin_login']))//this will tell us what to do if some data has been post through form with button.  
{  
    $admin_name=$_POST['admin_name'];  
    $admin_pass=$_POST['admin_pass'];  
  
    $admin_query="select * from admin where email='$admin_name' AND pass='".md5($admin_pass)."'";  
  echo $admin_query;
    $run_query = mysqli_query($con,$admin_query);  
  
    if(mysqli_num_rows($run_query)>0)  
    {  

        while($row = mysqli_fetch_assoc($run_query))
		{
		$_SESSION['SNK_admin'] = $row['id'];
        $_SESSION['SNK_email'] = $row['email']; //here session is used and value of $user_email store in $_SESSION. 
		$_SESSION['SNK_name'] = $row['admin_name'];
		
		$_SESSION['SNK_mobile'] = $row['mobile'];
		
		}

		echo "<meta http-equiv='refresh' content='0;url=./home.php'>"; 

  
        
    }  
    else {echo"<script>alert('Admin Details are incorrect..!')</script>";}  
  
}  
  
?>    
<div class="container">  
    <div class="row">  
        <div class="col-md-4 col-md-offset-4">  
            <div class="login-panel panel panel-success">  
                <div class="panel-heading">  
                    <h3 class="panel-title">Sign In</h3>  
                </div>  
                <div class="panel-body">  
                    <form role="form" method="post" >  
                        <fieldset>  
                            <div class="form-group"  >  
                                <input class="form-control" placeholder="Name" name="admin_name" type="text" autofocus>  
                            </div>  
                            <div class="form-group">  
                                <input class="form-control" placeholder="Password" name="admin_pass" type="password" value="">  
                            </div>  
  
  
                            <input class="btn btn-lg btn-success btn-block" type="submit" value="login" name="admin_login" >  
  
  
                        </fieldset>  
                    </form>  
                </div>  
            </div>  
        </div>  
    </div>  
</div>  
  
  
</body>  
  
</html>  
 