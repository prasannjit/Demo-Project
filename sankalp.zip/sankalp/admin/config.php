<?php
//$con = mysqli_connect("localhost","sankalpbuddhist_user","a_0unbYhgE+{","sankalpbuddhist_db");
$con = mysqli_connect("localhost","root","","sankalpbuddhist_db");
if(!$con)
{
	die("Database Connection Failed" . mysqli_error($con));
}
else
{
	// echo 'echo';
}
?>
