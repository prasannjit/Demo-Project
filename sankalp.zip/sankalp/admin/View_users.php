<?php  
session_start();  
if(isset($_SESSION['SNK_admin']) )
{   
$Page_Name = 'All the Users'; 
  include('header.php');
?> 
 
         <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"><?php echo $Page_Name; ?></h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
						<div class="panel-heading">
                            <?php echo $Page_Name; ?>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
<style>  
    .login-panel {  
        margin-top: 150px;  
    }  
    .table {  
        margin-top: 50px;  
  
    }  
  
</style>  
  
<body>  
  
<div class="table-scrol">  
    <h1 align="center">All the Users</h1>  
  
<div class="table-responsive"><!--this is used for responsive display in mobile and other devices-->  
  
  
    <table class="table table-bordered table-hover table-striped" style="table-layout: fixed">  
        <thead>  
  
        <tr>  
  
            <th>User Id</th>  
            <th>User Name</th>  
            <th>User E-mail</th>  
			<th>Status</th>
           
			<th>Change Password</th>
            <th>Delete User</th>  
        </tr>  
        </thead>  
  
        <?php  
        include("config.php");  
        $view_users_query="select * from members";//select query for viewing users.  
        $run=mysqli_query($con,$view_users_query);//here run the sql query.  
  
        while($row=mysqli_fetch_assoc($run))//while look to fetch the result and store in a array $row.  
        {  
            $user_id=$row['id'];  
            $user_name=$row['fname'].' '.$row['lname'];  
            $user_email=$row['email'];  
            $status =$row['status'];
  
        ?>  
  
        <tr>  
<!--here showing results in the table -->  
            <td><?php echo $id;  ?></td>  
            <td><?php echo $user_name;  ?></td>  
            <td><?php echo $user_email;  ?></td>  
			<td><?php if($status == 1) {
				echo 'paid'; 
				}else{
				echo 'unpaid'; 
			}   ?></td>  
             
			<td><a href="change_password.php?del=<?php echo $id ?>"><button class="btn btn-danger">Change Password</button></a></td>
            <td><a href="delete.php?del=<?php echo $id ?>"><button class="btn btn-danger">Delete</button></a></td> <!--btn btn-danger is a bootstrap button to show danger-->  
        </tr>  
  
        <?php } ?>  
  
    </table>  
        </div>  
</div>  
  
  
						</div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
 
        </div>
        <!-- /#page-wrapper -->

<?php 
include('footer.php');

}
else if(!$_SESSION['SNK_email'])  
{  
    header("Location: login.php");//redirect to login page to secure the welcome page without login access.  
}  
?>