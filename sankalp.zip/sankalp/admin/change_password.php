<?php  
session_start();  
if(isset($_SESSION['SNK_admin']) )
{   
$Page_Name = 'Home'; 
  include('header.php');
?> 
	<?php
  
include 'config.php';
  //include("customer/Db_conection.php");  
$delete_id = $_GET['del'];  

if(isset($_POST['change_password']))
{
$update_query = "update members set password = '". md5($_POST['confirm_new_password'])."' WHERE id=".$_POST['del_id'];//update query  
$run = mysqli_query($con,$delete_query);  
if($run)  
{  
//javascript function to open in the same window
	echo '<script > alert("password updated"); </script>';
    echo "<script>window.open('view_users.php','_self')</script>";  
}  
}
?>   
         <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"><?php echo $Page_Name; ?></h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
						<div class="panel-heading">
                            <?php echo $Page_Name; ?>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
					
					
					
<form role="form" class="form-horizontal" method="post"  enctype="multipart/form-data"
style="border: 1px solid #1e73be;">		
					
										<div class="form-group input-group">
										<label class="control-label" for="inputSuccess">Enter new password</label>
                                            <span class="input-group-addon">@</span>
                                            <input type="password" class="form-control" name="new_password" id="new_password" placeholder="password">
                                        </div>

										<div class="form-group input-group">
										<label class="control-label" for="inputSuccess">Enter confirm new password</label>
                                            <span class="input-group-addon">@</span>
                                            <input type="password" class="form-control" name="confirm_new_password" id="confirm_new_password" placeholder="password">
                                        </div>
										<div class="form-group input-group">
                                            <span class="input-group-addon">@</span>
                                            <input type="submit" class="form-control" placeholder="change_password" id="change_password" disabled>
											 <input type="hidden" class="form-control" name="del_id" value="<?php echo $delete_id; ?>">
                                        </div>

 </form>
						</div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
 
        </div>
        <!-- /#page-wrapper -->
<script>
$(function(){
	$('#confirm_new_password').change(function(){
		var new_password = $('#new_password').val();
		var confirm_new_password = $('#confirm_new_password').val();
		if(new_password !='' && confirm_new_password !="")
		{
			if(new_password == confirm_new_password)
			{
				$('#change_password').attr('disabled', false);
			}
			else{
				$('#change_password').attr('disabled', true);
			}
		}
		else{
			$('#change_password').attr('disabled', true);
		}
	});
	
})
</script>
<?php 
include('footer.php');

}
else if(!$_SESSION['SNK_email'])  
{  
    header("Location: login.php");//redirect to login page to secure the welcome page without login access.  
}  
?>