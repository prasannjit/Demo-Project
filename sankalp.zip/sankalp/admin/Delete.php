<?php  
session_start();  
if(isset($_SESSION['SNK_admin']) )
{   
$Page_Name = 'delete'; 

  
include 'config.php';
  //include("customer/Db_conection.php");  
$delete_id = $_GET['del'];  
$delete_query = "delete  from members WHERE id='$delete_id'";//delete query  
$run = mysqli_query($con,$delete_query);  
if($run)  
{  
//javascript function to open in the same window   
    echo "<script>window.open('view_users.php?deleted=user has been deleted','_self')</script>";  
}  
  
?>  
 
						</div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
 
        </div>
        <!-- /#page-wrapper -->

<?php 


}
else if(!$_SESSION['SNK_email'])  
{  
    header("Location: login.php");//redirect to login page to secure the welcome page without login access.  
}  
?>