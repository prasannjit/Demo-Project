<div class="navbar-default sidebar" role="navigation">
                 <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        
                        <li>
                            <a href="home.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
						 <li>
                            <a href="View_users.php"><i class="fa fa-table fa-fw"></i> View All</a>
                        </li>
						<li><?php  ?><a href="grooms.php"><i class="fa fa-table fa-fw"></i>  Grooms </a>  
						</li>
						
						<li><?php ?><a href="bride.php"><i class="fa fa-table fa-fw"></i>  Bride </a>  
						</li>
						
                        <li><a href="profile.php"><i class="fa fa-user fa-fw"></i> User Profile</a> </li>
                        
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>